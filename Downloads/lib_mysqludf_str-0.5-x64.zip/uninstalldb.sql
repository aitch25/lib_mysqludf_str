use mysql;

drop function if exists lib_mysqludf_str_info;
drop function if exists str_numtowords;
drop function if exists str_rot13;
drop function if exists str_shuffle;
drop function if exists str_translate;
drop function if exists str_ucfirst;
drop function if exists str_ucwords;
drop function if exists str_xor;
drop function if exists str_srand;
